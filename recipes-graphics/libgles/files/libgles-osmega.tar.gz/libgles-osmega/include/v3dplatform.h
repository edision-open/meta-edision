/*=============================================================================
Copyright (c) 2010 Broadcom Europe Limited.
All rights reserved.
=============================================================================*/

#ifndef __V3D_PLATFORM_H__
#define __V3D_PLATFORM_H__

#include <stdbool.h>
#include <stdint.h>
#include <EGL/egl.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void *V3D_PlatformHandle;

typedef struct {
   uint32_t    width;
   uint32_t    height;
   uint32_t    x;
   uint32_t    y;
   bool        stretch;
   uint32_t    clientID;
   uint32_t    zOrder;
} V3D_NativeWindowInfo;

extern void V3D_RegisterDisplayPlatform(V3D_PlatformHandle *handle, void *display);
extern void V3D_UnregisterDisplayPlatform(V3D_PlatformHandle handle);
extern bool V3D_SetVisible(V3D_PlatformHandle handle, bool visible);
extern bool V3D_BufferGetRequirements(V3D_PlatformHandle handle, BEGL_PixmapInfo *bufferRequirements, BEGL_BufferSettings * bufferConstrainedRequirements);
extern bool V3D_CreateCompatiblePixmap(V3D_PlatformHandle handle, void **pixmapHandle, void **pixmapBuffer, BEGL_PixmapInfo *info);
extern void V3D_DestroyCompatiblePixmap(V3D_PlatformHandle handle, void *pixmapHandle);
extern void *V3D_CreateNativeWindow(const V3D_NativeWindowInfo *info);
extern void V3D_DestroyNativeWindow(void *nativeWin);

#ifdef __cplusplus
}
#endif

#endif /* !__V3D_PLATFORM_H__ */
